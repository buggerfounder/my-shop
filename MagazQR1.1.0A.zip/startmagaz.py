import os
import cv2
import time
import json
from pyzbar import pyzbar
from datetime import datetime, timedelta
import qrcode
import shutil
from tkinter import messagebox, simpledialog, filedialog
import tkinter as tk
import hashlib
from getpass import getpass
import sys
import csv
from collections import defaultdict

# Конфигурация системы
CONFIG = {
    'data_dir': 'data',
    'cards_file': 'cards.json',
    'products_file': 'products.json',
    'history_file': 'history.json',
    'backup_dir': 'backups',
    'admin_password_hash': '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',  # sha256('password')
    'discount_threshold': 500,
    'discount_percent': 10,
    'pin_required_threshold': 100,
    'bonus_percent': 5,
    'language': 'ru',
    'inventory_enabled': True,
    'receipt_counter': 0
}

# Локализация интерфейса
LANGUAGES = {
    'ru': {
        'main_menu': "=== ГЛАВНОЕ МЕНЮ ===",
        'shopping': "Режим покупок",
        'admin': "Администратор",
        'exit': "Выход",
        'choose_option': "Выберите действие: ",
        'cart_empty': "Корзина пуста!",
        'product_added': "Товар добавлен",
        'payment_complete': "Оплата завершена",
        # ... другие строки ...
    },
    'en': {
        'main_menu': "=== MAIN MENU ===",
        'shopping': "Shopping mode",
        'admin': "Administrator",
        'exit': "Exit",
        'choose_option': "Choose an option: ",
        'cart_empty': "Cart is empty!",
        'product_added': "Product added",
        'payment_complete': "Payment complete",
        # ... другие строки ...
    }
}

class Translator:
    @staticmethod
    def translate(key):
        return LANGUAGES[CONFIG['language']].get(key, key)

class ShoppingCart:
    def __init__(self):
        self.items = []
        self.total = 0
        self.discount = 0
        self.scanned_codes = set()
        self.bonus_earned = 0
        self.bonus_used = 0
    
    def add_item(self, product, quantity=1):
        if not ProductSystem.check_stock(product['code'], quantity):
            print(f"Недостаточно товара {product['name']} на складе!")
            return False
        
        existing = next((item for item in self.items if item['product']['code'] == product['code']), None)
        
        if existing:
            existing['quantity'] += quantity
            print(f"Количество {product['name']} увеличено до {existing['quantity']}")
        else:
            self.items.append({
                'product': product,
                'quantity': quantity,
                'added_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
            self.scanned_codes.add(product['code'])
            print(f"Добавлено: {product['name']} x{quantity}")
        
        self.calculate_totals()
        return True
    
    def remove_item(self, index):
        if 0 <= index < len(self.items):
            removed = self.items.pop(index)
            self.scanned_codes.remove(removed['product']['code'])
            print(f"Удалено: {removed['product']['name']}")
            self.calculate_totals()
            return True
        return False
    
    def update_quantity(self, index, new_quantity):
        if 0 <= index < len(self.items):
            product_code = self.items[index]['product']['code']
            if not ProductSystem.check_stock(product_code, new_quantity - self.items[index]['quantity']):
                print("Недостаточно товара на складе!")
                return False
            
            if new_quantity > 0:
                self.items[index]['quantity'] = new_quantity
                self.calculate_totals()
                return True
            elif new_quantity == 0:
                return self.remove_item(index)
        return False
    
    def calculate_totals(self):
        self.total = sum(item['product']['price'] * item['quantity'] for item in self.items)
        self.discount = (self.total * CONFIG['discount_percent'] / 100 
                        if self.total >= CONFIG['discount_threshold'] else 0)
        self.bonus_earned = self.get_final_total() * (CONFIG['bonus_percent'] / 100)
    
    def get_final_total(self):
        return round(self.total - self.discount, 2)
    
    def clear(self):
        self.items = []
        self.scanned_codes = set()
        self.total = 0
        self.discount = 0
        self.bonus_earned = 0
        self.bonus_used = 0
        print("Корзина очищена")
    
    def display(self):
        if not self.items:
            print("\nКорзина пуста")
            return False
        
        print("\n=== ВАША КОРЗИНА ===")
        for i, item in enumerate(self.items, 1):
            p = item['product']
            print(f"{i}. {p['name']} ({p['code']}) - {p['price']} руб. x{item['quantity']} = {p['price'] * item['quantity']} руб.")
        
        if self.discount > 0:
            print(f"\nСкидка {CONFIG['discount_percent']}%: -{self.discount:.2f} руб.")
        if self.bonus_used > 0:
            print(f"Использовано бонусов: -{self.bonus_used:.2f} руб.")
        print(f"ИТОГО: {self.get_final_total():.2f} руб.")
        
        if self.bonus_earned > 0:
            print(f"Будет начислено бонусов: {self.bonus_earned:.2f} руб.")
        return True
    
    def edit_interactive(self):
        while True:
            if not self.display():
                return
            
            print("\n1. Изменить количество")
            print("2. Удалить товар")
            print("3. Вернуться")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                try:
                    idx = int(input("Номер товара: ")) - 1
                    if 0 <= idx < len(self.items):
                        new_qty = int(input(f"Новое количество (текущее: {self.items[idx]['quantity']}): "))
                        if not self.update_quantity(idx, new_qty):
                            print("Неверное количество!")
                    else:
                        print("Неверный номер товара!")
                except ValueError:
                    print("Ошибка ввода!")
            
            elif choice == '2':
                try:
                    idx = int(input("Номер товара для удаления: ")) - 1
                    if not self.remove_item(idx):
                        print("Неверный номер товара!")
                except ValueError:
                    print("Ошибка ввода!")
            
            elif choice == '3':
                return
            
            else:
                print("Неверный выбор!")
    
    def apply_bonuses(self, card_index, amount):
        cards = CardSystem.get_cards()
        if 0 <= card_index < len(cards):
            available_bonuses = cards[card_index].get('bonuses', 0)
            if amount <= available_bonuses:
                self.bonus_used = amount
                cards[card_index]['bonuses'] -= amount
                CardSystem.save_cards(cards)
                return True
        return False

class DataManager:
    @staticmethod
    def load_data(filename):
        path = os.path.join(CONFIG['data_dir'], filename)
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    @staticmethod
    def save_data(filename, data):
        path = os.path.join(CONFIG['data_dir'], filename)
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    @staticmethod
    def backup():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        os.makedirs(CONFIG['backup_dir'], exist_ok=True)
        
        for file in [CONFIG['cards_file'], CONFIG['products_file'], CONFIG['history_file']]:
            src = os.path.join(CONFIG['data_dir'], file)
            dst = os.path.join(CONFIG['backup_dir'], f"{timestamp}_{file}")
            if os.path.exists(src):
                shutil.copy2(src, dst)
        
        print(f"\nСоздана резервная копия {timestamp}")

class CardSystem:
    @staticmethod
    def get_cards():
        return DataManager.load_data(CONFIG['cards_file'])
    
    @staticmethod
    def save_cards(cards):
        DataManager.save_data(CONFIG['cards_file'], cards)
    
    @staticmethod
    def register_card():
        print("\n=== РЕГИСТРАЦИЯ КАРТЫ ===")
        print("1. Стандартная карта")
        print("2. QR-карта")
        card_type = input("Выберите тип: ")
        
        if card_type not in ['1', '2']:
            print("Неверный выбор!")
            return
        
        card_type = 'standard' if card_type == '1' else 'qr'
        
        while True:
            number = input("Номер карты (16 цифр): ").strip()
            if len(number) != 16 or not number.isdigit():
                print("Номер должен содержать 16 цифр!")
                continue
            
            pin = getpass("PIN-код (4 цифры): ")
            if len(pin) != 4 or not pin.isdigit():
                print("PIN должен содержать 4 цифры!")
                continue
            
            try:
                balance = float(input("Начальный баланс: "))
                if balance < 0:
                    print("Баланс не может быть отрицательным!")
                    continue
                break
            except ValueError:
                print("Неверная сумма!")
        
        cards = CardSystem.get_cards()
        new_card = {
            'number': number,
            'pin': pin,
            'balance': balance,
            'type': card_type,
            'bonuses': 0,
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        if card_type == 'qr':
            qr_data = json.dumps([number, pin[:2] + '**', balance, 'qr'])
            qr = qrcode.QRCode(version=1, box_size=10, border=4)
            qr.add_data(qr_data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            filename = f"qr_card_{number[-4:]}.png"
            img.save(filename)
            print(f"\nQR-код сохранен как {filename}")
        
        cards.append(new_card)
        CardSystem.save_cards(cards)
        print("\nКарта успешно зарегистрирована!")
    
    @staticmethod
    def add_bonuses(card_number, amount):
        cards = CardSystem.get_cards()
        for card in cards:
            if card['number'] == card_number:
                card['bonuses'] = card.get('bonuses', 0) + amount
                CardSystem.save_cards(cards)
                return True
        return False

class ProductSystem:
    @staticmethod
    def get_products():
        return DataManager.load_data(CONFIG['products_file'])
    
    @staticmethod
    def save_products(products):
        DataManager.save_data(CONFIG['products_file'], products)
    
    @staticmethod
    def register_product():
        print("\n=== РЕГИСТРАЦИЯ ТОВАРА ===")
        
        while True:
            try:
                code = int(input("Код товара: "))
                name = input("Название: ").strip()
                if not name:
                    raise ValueError
                
                price = float(input("Цена: "))
                if price <= 0:
                    print("Цена должна быть положительной!")
                    continue
                
                if CONFIG['inventory_enabled']:
                    quantity = float(input("Начальное количество: "))
                    if quantity < 0:
                        print("Количество не может быть отрицательным!")
                        continue
                else:
                    quantity = None
                
                break
            except ValueError:
                print("Неверные данные!")
        
        products = ProductSystem.get_products()
        product_data = {
            'code': code,
            'name': name,
            'price': price,
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        if CONFIG['inventory_enabled']:
            product_data['quantity'] = quantity
        
        products.append(product_data)
        
        qr_data = json.dumps([code, name, price])
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        filename = f"product_{code}.png"
        img.save(filename)
        print(f"\nQR-код сохранен как {filename}")
        
        ProductSystem.save_products(products)
        print("\nТовар успешно зарегистрирован!")
    
    @staticmethod
    def check_stock(product_code, requested_quantity):
        if not CONFIG['inventory_enabled']:
            return True
        
        products = ProductSystem.get_products()
        for product in products:
            if product['code'] == product_code:
                return product.get('quantity', 0) >= requested_quantity
        return False
    
    @staticmethod
    def update_stock(product_code, quantity_change):
        if not CONFIG['inventory_enabled']:
            return False
        
        products = ProductSystem.get_products()
        for product in products:
            if product['code'] == product_code:
                if 'quantity' not in product:
                    product['quantity'] = 0
                product['quantity'] += quantity_change
                if product['quantity'] < 0:
                    product['quantity'] = 0
                ProductSystem.save_products(products)
                return True
        return False
    
    @staticmethod
    def search_products():
        print("\n=== ПОИСК ТОВАРОВ ===")
        search_term = input("Введите название или код товара: ").lower()
        
        products = ProductSystem.get_products()
        found = []
        
        for product in products:
            if (search_term in str(product['code']).lower() or 
                search_term in product['name'].lower()):
                found.append(product)
        
        if not found:
            print("Товары не найдены!")
            return
        
        print("\nРезультаты поиска:")
        for i, product in enumerate(found, 1):
            stock = f", Остаток: {product['quantity']}" if CONFIG['inventory_enabled'] and 'quantity' in product else ""
            print(f"{i}. {product['name']} (код: {product['code']}, цена: {product['price']} руб.{stock})")
        
        input("\nНажмите Enter чтобы продолжить...")

class Scanner:
    @staticmethod
    def scan_product(cart):
        cap = None
        try:
            cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not cap.isOpened():
                print("\nОшибка: Камера недоступна")
                return
            
            print("\n=== РЕЖИМ СКАНИРОВАНИЯ ===")
            print("Наведите камеру на QR-код товара")
            print("ESC - выход, SPACE - вручную")
            
            last_scan = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    print("Ошибка получения изображения")
                    break
                
                current_time = time.time()
                if current_time - last_scan > 1:
                    try:
                        decoded = pyzbar.decode(frame)
                        for obj in decoded:
                            data = obj.data.decode('utf-8')
                            if data.startswith('[') and data.endswith(']'):
                                product_data = json.loads(data)
                                if len(product_data) >= 3:
                                    product = {
                                        'code': product_data[0],
                                        'name': product_data[1],
                                        'price': product_data[2]
                                    }
                                    
                                    try:
                                        qty = int(input(f"\nВведите количество для {product['name']} (по умолчанию 1): ") or 1)
                                        if cart.add_item(product, qty):
                                            last_scan = current_time
                                            cv2.rectangle(frame, (0, 0), (frame.shape[1], frame.shape[0]), (0, 255, 0), 10)
                                            print(f"Добавлено: {product['name']} x{qty}")
                                    except ValueError:
                                        print("Используется количество 1")
                                        if cart.add_item(product, 1):
                                            last_scan = current_time
                                            cv2.rectangle(frame, (0, 0), (frame.shape[1], frame.shape[0]), (0, 255, 0), 10)
                    except Exception as e:
                        pass
                
                cv2.imshow('Сканер (ESC - выход)', frame)
                
                key = cv2.waitKey(1)
                if key == 27:
                    break
                elif key == 32:
                    code = input("\nВведите код товара вручную: ")
                    name = input("Название товара: ")
                    try:
                        price = float(input("Цена: "))
                        qty = int(input("Количество: ") or 1)
                        
                        product = {
                            'code': code,
                            'name': name,
                            'price': price
                        }
                        cart.add_item(product, qty)
                    except ValueError:
                        print("Ошибка ввода данных!")
        finally:
            if cap:
                cap.release()
            cv2.destroyAllWindows()

class PaymentSystem:
    @staticmethod
    def process_payment(cart):
        if not cart.items:
            print("\nКорзина пуста!")
            return
        
        while True:
            print("\n=== ВЫБОР СПОСОБА ОПЛАТЫ ===")
            print("1. Стандартная карта")
            print("2. QR-карта")
            print("3. Наличные")
            print("4. Отмена")
            
            choice = input("Выберите способ: ")
            total = cart.get_final_total()
            
            if choice == '1':
                PaymentSystem.pay_by_standard_card(cart, total)
                break
            elif choice == '2':
                PaymentSystem.pay_by_qr_card(cart, total)
                break
            elif choice == '3':
                PaymentSystem.pay_by_cash(cart, total)
                break
            elif choice == '4':
                break
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def pay_by_standard_card(cart, total):
        cards = [c for c in CardSystem.get_cards() if c['type'] == 'standard']
        if not cards:
            print("\nНет доступных стандартных карт!")
            return
        
        print("\n=== ОПЛАТА СТАНДАРТНОЙ КАРТОЙ ===")
        cart.display()
        
        print("\nДоступные карты:")
        for i, card in enumerate(cards, 1):
            bonuses = card.get('bonuses', 0)
            print(f"{i}. ****{card['number'][-4:]}, Баланс: {card['balance']:.2f} руб., Бонусы: {bonuses:.2f} руб.")
        
        try:
            idx = int(input("\nВыберите карту: ")) - 1
            if 0 <= idx < len(cards):
                card = cards[idx]
                
                use_bonuses = input(f"Использовать бонусы (доступно {card.get('bonuses', 0):.2f} руб.)? (да/нет): ").lower()
                if use_bonuses == 'да':
                    try:
                        bonus_amount = float(input(f"Сколько бонусов использовать (макс {card.get('bonuses', 0):.2f} руб.): "))
                        bonus_amount = min(bonus_amount, card.get('bonuses', 0), total)
                        if bonus_amount > 0:
                            if cart.apply_bonuses(idx, bonus_amount):
                                total -= bonus_amount
                                print(f"Применено бонусов: {bonus_amount:.2f} руб.")
                                print(f"Остаток к оплате: {total:.2f} руб.")
                    except ValueError:
                        print("Неверная сумма бонусов!")
                
                if total > card['balance']:
                    print("\nНедостаточно средств на карте!")
                    return
                
                if total >= CONFIG['pin_required_threshold']:
                    pin = getpass("Введите PIN-код: ")
                    if pin != card['pin']:
                        print("\nНеверный PIN-код!")
                        return
                
                print(f"\nСумма к оплате: {total:.2f} руб.")
                confirm = input("Подтвердить оплату (да/нет): ").lower()
                if confirm != 'да':
                    print("Оплата отменена")
                    return
                
                cards[idx]['balance'] -= total
                bonuses_earned = cart.calculate_bonuses()
                cards[idx]['bonuses'] = cards[idx].get('bonuses', 0) + bonuses_earned
                CardSystem.save_cards(cards)
                
                CONFIG['receipt_counter'] += 1
                receipt_id = f"R{CONFIG['receipt_counter']:06d}"
                
                PaymentSystem.save_receipt(
                    payment_method="Стандартная карта",
                    items=cart.items,
                    total=total + cart.bonus_used,
                    card_number=card['number'],
                    bonuses_used=cart.bonus_used,
                    bonus_earned=bonuses_earned,
                    receipt_id=receipt_id
                )
                
                PaymentSystem.show_receipt(
                    items=cart.items,
                    total=total + cart.bonus_used,
                    payment_method="Стандартная карта",
                    card_number=card['number'],
                    bonuses_used=cart.bonus_used,
                    bonus_earned=bonuses_earned,
                    receipt_id=receipt_id
                )
                
                if CONFIG['inventory_enabled']:
                    for item in cart.items:
                        ProductSystem.update_stock(item['product']['code'], -item['quantity'])
                
                cart.clear()
            else:
                print("Неверный номер карты!")
        except ValueError:
            print("Ошибка ввода!")
    
    @staticmethod
    def pay_by_qr_card(cart, total):
        print("\n=== ОПЛАТА QR-КАРТОЙ ===")
        print("Поднесите QR-код карты к камере...")
        
        cap = None
        try:
            cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not cap.isOpened():
                print("\nОшибка: Камера недоступна")
                return
            
            cards = CardSystem.get_cards()
            qr_cards = [c for c in cards if c['type'] == 'qr']
            
            found = None
            while not found:
                ret, frame = cap.read()
                if not ret:
                    print("Ошибка получения изображения")
                    break
                
                try:
                    decoded = pyzbar.decode(frame)
                    for obj in decoded:
                        data = obj.data.decode('utf-8')
                        if data.startswith('[') and data.endswith(']'):
                            card_data = json.loads(data)
                            if len(card_data) >= 3:
                                for card in qr_cards:
                                    if str(card['number']) == str(card_data[0]):
                                        found = card
                                        break
                except:
                    pass
                
                cv2.imshow('Сканирование QR-карты (ESC - отмена)', frame)
                if cv2.waitKey(1) == 27:
                    break
            
            if found:
                if total > found['balance']:
                    print("\nНедостаточно средств на карте!")
                    return
                
                for i, card in enumerate(cards):
                    if card['number'] == found['number']:
                        cards[i]['balance'] -= total
                        bonuses_earned = cart.calculate_bonuses()
                        cards[i]['bonuses'] = cards[i].get('bonuses', 0) + bonuses_earned
                        break
                
                CardSystem.save_cards(cards)
                
                CONFIG['receipt_counter'] += 1
                receipt_id = f"R{CONFIG['receipt_counter']:06d}"
                
                PaymentSystem.save_receipt(
                    payment_method="QR-карта",
                    items=cart.items,
                    total=total,
                    card_number=found['number'],
                    bonus_earned=bonuses_earned,
                    receipt_id=receipt_id
                )
                
                PaymentSystem.show_receipt(
                    items=cart.items,
                    total=total,
                    payment_method="QR-карта",
                    card_number=found['number'],
                    bonus_earned=bonuses_earned,
                    receipt_id=receipt_id
                )
                
                if CONFIG['inventory_enabled']:
                    for item in cart.items:
                        ProductSystem.update_stock(item['product']['code'], -item['quantity'])
                
                cart.clear()
            else:
                print("\nQR-карта не распознана")
        finally:
            if cap:
                cap.release()
            cv2.destroyAllWindows()
    
    @staticmethod
    def pay_by_cash(cart, total):
        print("\n=== ОПЛАТА НАЛИЧНЫМИ ===")
        cart.display()
        
        while True:
            try:
                cash = float(input("\nВнесенная сумма: "))
                if cash < total:
                    print(f"Не хватает {total - cash:.2f} руб.")
                    continue
                
                change = cash - total
                print(f"\nСдача: {change:.2f} руб.")
                
                confirm = input("Подтвердите оплату (да/нет): ").lower()
                if confirm != 'да':
                    print("Отменено")
                    return
                
                CONFIG['receipt_counter'] += 1
                receipt_id = f"R{CONFIG['receipt_counter']:06d}"
                
                PaymentSystem.save_receipt(
                    payment_method="Наличные",
                    items=cart.items,
                    total=total,
                    cash_received=cash,
                    change=change,
                    receipt_id=receipt_id
                )
                
                PaymentSystem.show_receipt(
                    items=cart.items,
                    total=total,
                    payment_method="Наличные",
                    cash_received=cash,
                    change=change,
                    receipt_id=receipt_id
                )
                
                if CONFIG['inventory_enabled']:
                    for item in cart.items:
                        ProductSystem.update_stock(item['product']['code'], -item['quantity'])
                
                cart.clear()
                break
            except ValueError:
                print("Неверная сумма!")
    
    @staticmethod
    def save_receipt(payment_method, items, total, **kwargs):
        receipt = {
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'payment_method': payment_method,
            'items': [{
                'product': item['product'],
                'quantity': item['quantity'],
                'price': item['product']['price']
            } for item in items],
            'total': total,
            **kwargs
        }
        
        history = DataManager.load_data(CONFIG['history_file'])
        history.append(receipt)
        DataManager.save_data(CONFIG['history_file'], history)
    
    @staticmethod
    def show_receipt(items, total, payment_method, **kwargs):
        root = tk.Tk()
        root.withdraw()
        
        receipt = f"=== ЧЕК #{kwargs.get('receipt_id', 'N/A')} ===\n\n"
        receipt += f"Дата: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}\n"
        receipt += f"Способ оплаты: {payment_method}\n"
        
        if 'card_number' in kwargs:
            receipt += f"Карта: ****{kwargs['card_number'][-4:]}\n"
        if 'cash_received' in kwargs:
            receipt += f"Внесено: {kwargs['cash_received']:.2f} руб.\n"
            receipt += f"Сдача: {kwargs['change']:.2f} руб.\n"
        if 'bonuses_used' in kwargs and kwargs['bonuses_used'] > 0:
            receipt += f"Использовано бонусов: {kwargs['bonuses_used']:.2f} руб.\n"
        if 'bonus_earned' in kwargs and kwargs['bonus_earned'] > 0:
            receipt += f"Начислено бонусов: {kwargs['bonus_earned']:.2f} руб.\n"
        
        receipt += "\nТОВАРЫ:\n"
        for item in items:
            p = item['product']
            receipt += f"{p['name']:20} {p['price']:>7.2f} x{item['quantity']} = {p['price'] * item['quantity']:>7.2f} руб.\n"
        
        receipt += f"\n{'ИТОГО:':20} {total:>7.2f} руб.\n"
        receipt += "\nСпасибо за покупку!"
        
        messagebox.showinfo("Чек", receipt)
        root.destroy()

class ReturnSystem:
    @staticmethod
    def return_purchase():
        print("\n=== ВОЗВРАТ ТОВАРА ===")
        
        purchase_id = input("Введите номер чека или дату покупки (ДД.ММ.ГГГГ): ")
        purchases = DataManager.load_data(CONFIG['history_file'])
        
        found_purchases = []
        for purchase in purchases:
            if purchase.get('type') == 'return':
                continue
            
            if (purchase_id in purchase.get('receipt_id', '') or 
                purchase_id in purchase['date']):
                found_purchases.append(purchase)
        
        if not found_purchases:
            print("Покупка не найдена!")
            return
        
        print("\nНайденные покупки:")
        for i, purchase in enumerate(found_purchases, 1):
            print(f"{i}. Чек #{purchase.get('receipt_id', 'N/A')} от {purchase['date']}")
        
        try:
            choice = int(input("Выберите покупку для возврата: ")) - 1
            if 0 <= choice < len(found_purchases):
                purchase = found_purchases[choice]
                ReturnSystem.process_return(purchase)
            else:
                print("Неверный выбор!")
        except ValueError:
            print("Ошибка ввода!")
    
    @staticmethod
    def process_return(purchase):
        print(f"\nВозврат по чеку #{purchase.get('receipt_id', 'N/A')}")
        print(f"Дата: {purchase['date']}")
        print(f"Способ оплаты: {purchase['payment_method']}")
        
        items_to_return = []
        for i, item in enumerate(purchase['items'], 1):
            print(f"{i}. {item['product']['name']} x{item['quantity']} - {item['product']['price']} руб.")
        
        print("\nВыберите товары для возврата (через запятую или 'all' для всех):")
        choice = input("Ваш выбор: ")
        
        if choice.strip().lower() == 'all':
            items_to_return = purchase['items']
        else:
            try:
                selected = [int(x.strip()) - 1 for x in choice.split(',')]
                items_to_return = [purchase['items'][i] for i in selected 
                                 if 0 <= i < len(purchase['items'])]
            except ValueError:
                print("Ошибка ввода!")
                return
        
        if not items_to_return:
            print("Не выбрано ни одного товара!")
            return
        
        return_amount = sum(item['product']['price'] * item['quantity'] 
                          for item in items_to_return)
        
        print(f"\nСумма к возврату: {return_amount:.2f} руб.")
        confirm = input("Подтвердить возврат (да/нет): ").lower()
        if confirm != 'да':
            print("Возврат отменен")
            return
        
        if purchase['payment_method'] == "Наличные":
            print(f"Верните покупателю {return_amount:.2f} руб. наличными")
        else:
            card_number = purchase.get('card_number')
            if card_number:
                cards = CardSystem.get_cards()
                for card in cards:
                    if card['number'] == card_number:
                        card['balance'] += return_amount
                        if 'bonus_earned' in purchase:
                            bonus_to_deduct = min(purchase['bonus_earned'], 
                                                card.get('bonuses', 0))
                            card['bonuses'] -= bonus_to_deduct
                        CardSystem.save_cards(cards)
                        print(f"Средства возвращены на карту ****{card_number[-4:]}")
                        break
        
        if CONFIG['inventory_enabled']:
            products = ProductSystem.get_products()
            for item in items_to_return:
                for product in products:
                    if product['code'] == item['product']['code']:
                        product['quantity'] = product.get('quantity', 0) + item['quantity']
            ProductSystem.save_products(products)
        
        return_data = {
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'original_receipt': purchase.get('receipt_id', 'N/A'),
            'returned_items': items_to_return,
            'amount': return_amount,
            'payment_method': purchase['payment_method']
        }
        
        CONFIG['receipt_counter'] += 1
        return_id = f"RT{CONFIG['receipt_counter']:06d}"
        
        history = DataManager.load_data(CONFIG['history_file'])
        history.append({
            'type': 'return',
            'receipt_id': return_id,
            'data': return_data
        })
        DataManager.save_data(CONFIG['history_file'], history)
        
        print("\nВозврат успешно оформлен!")
        
        root = tk.Tk()
        root.withdraw()
        
        receipt = f"=== ВОЗВРАТ #{return_id} ===\n\n"
        receipt += f"Дата: {return_data['date']}\n"
        receipt += f"Оригинальный чек: #{return_data['original_receipt']}\n"
        receipt += f"Способ возврата: {return_data['payment_method']}\n"
        receipt += f"Сумма возврата: {return_data['amount']:.2f} руб.\n"
        
        receipt += "\nВОЗВРАЩЕННЫЕ ТОВАРЫ:\n"
        for item in return_data['returned_items']:
            p = item['product']
            receipt += f"{p['name']:20} {p['price']:>7.2f} x{item['quantity']} = {p['price'] * item['quantity']:>7.2f} руб.\n"
        
        messagebox.showinfo("Чек возврата", receipt)
        root.destroy()

class ReportSystem:
    @staticmethod
    def generate_report():
        print("\n=== ГЕНЕРАЦИЯ ОТЧЕТОВ ===")
        print("1. Отчет по продажам за период")
        print("2. Отчет по возвратам")
        print("3. Отчет по товарам")
        print("4. Финансовый отчет")
        print("5. Назад")
        
        choice = input("Выберите тип отчета: ")
        
        if choice == '1':
            ReportSystem.generate_sales_report()
        elif choice == '2':
            ReportSystem.generate_returns_report()
        elif choice == '3':
            ReportSystem.generate_products_report()
        elif choice == '4':
            ReportSystem.generate_financial_report()
        elif choice == '5':
            return
        else:
            print("Неверный выбор!")
    
    @staticmethod
    def generate_sales_report():
        print("\n=== ОТЧЕТ ПО ПРОДАЖАМ ===")
        
        try:
            start_date = input("Начальная дата (ДД.ММ.ГГГГ или Enter): ")
            end_date = input("Конечная дата (ДД.ММ.ГГГГ или Enter): ")
            
            purchases = DataManager.load_data(CONFIG['history_file'])
            
            filtered = []
            for purchase in purchases:
                if purchase.get('type') == 'return':
                    continue
                
                purchase_date = datetime.strptime(purchase['date'], '%Y-%m-%d %H:%M:%S')
                
                if start_date:
                    try:
                        start = datetime.strptime(start_date, '%d.%m.%Y')
                        if purchase_date < start:
                            continue
                    except ValueError:
                        print("Неверный формат начальной даты!")
                        return
                
                if end_date:
                    try:
                        end = datetime.strptime(end_date, '%d.%m.%Y') + timedelta(days=1)
                        if purchase_date >= end:
                            continue
                    except ValueError:
                        print("Неверный формат конечной даты!")
                        return
                
                filtered.append(purchase)
            
            if not filtered:
                print("Нет данных за указанный период!")
                return
            
            total_sales = sum(p['total'] for p in filtered)
            total_items = sum(sum(i['quantity'] for i in p['items']) for p in filtered)
            total_bonuses = sum(p.get('bonus_earned', 0) for p in filtered)
            
            print(f"\nПериод: {start_date or 'начало'} - {end_date or 'конец'}")
            print(f"Количество чеков: {len(filtered)}")
            print(f"Количество проданных товаров: {total_items}")
            print(f"Общая сумма продаж: {total_sales:.2f} руб.")
            print(f"Всего начислено бонусов: {total_bonuses:.2f} руб.")
            
            product_stats = defaultdict(lambda: {'quantity': 0, 'amount': 0})
            for purchase in filtered:
                for item in purchase['items']:
                    product = item['product']
                    product_stats[product['name']]['quantity'] += item['quantity']
                    product_stats[product['name']]['amount'] += product['price'] * item['quantity']
            
            print("\nТОП-5 товаров по количеству:")
            for product in sorted(product_stats.items(), key=lambda x: -x[1]['quantity'])[:5]:
                print(f"{product[0]}: {product[1]['quantity']} шт.")
            
            print("\nТОП-5 товаров по сумме:")
            for product in sorted(product_stats.items(), key=lambda x: -x[1]['amount'])[:5]:
                print(f"{product[0]}: {product[1]['amount']:.2f} руб.")
            
            export = input("\nЭкспортировать в CSV (да/нет)? ").lower()
            if export == 'да':
                filename = filedialog.asksaveasfilename(
                    defaultextension=".csv",
                    filetypes=[("CSV files", "*.csv")],
                    title="Сохранить отчет как"
                )
                if filename:
                    with open(filename, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f, delimiter=';')
                        writer.writerow(['Дата', 'Номер чека', 'Кол-во товаров', 'Сумма', 'Способ оплаты', 'Бонусы'])
                        for purchase in filtered:
                            writer.writerow([
                                purchase['date'],
                                purchase.get('receipt_id', 'N/A'),
                                sum(i['quantity'] for i in purchase['items']),
                                purchase['total'],
                                purchase['payment_method'],
                                purchase.get('bonus_earned', 0)
                            ])
                    print(f"Отчет сохранен как {filename}")
        
        except Exception as e:
            print(f"Ошибка при генерации отчета: {str(e)}")
    
    @staticmethod
    def generate_returns_report():
        print("\n=== ОТЧЕТ ПО ВОЗВРАТАМ ===")
        
        try:
            start_date = input("Начальная дата (ДД.ММ.ГГГГ или Enter): ")
            end_date = input("Конечная дата (ДД.ММ.ГГГГ или Enter): ")
            
            history = DataManager.load_data(CONFIG['history_file'])
            
            returns = []
            for record in history:
                if record.get('type') == 'return':
                    return_date = datetime.strptime(record['data']['date'], '%Y-%m-%d %H:%M:%S')
                    
                    if start_date:
                        try:
                            start = datetime.strptime(start_date, '%d.%m.%Y')
                            if return_date < start:
                                continue
                        except ValueError:
                            print("Неверный формат начальной даты!")
                            return
                    
                    if end_date:
                        try:
                            end = datetime.strptime(end_date, '%d.%m.%Y') + timedelta(days=1)
                            if return_date >= end:
                                continue
                        except ValueError:
                            print("Неверный формат конечной даты!")
                            return
                    
                    returns.append(record)
            
            if not returns:
                print("Нет данных за указанный период!")
                return
            
            total_returns = sum(r['data']['amount'] for r in returns)
            total_items = sum(len(r['data']['returned_items']) for r in returns)
            
            print(f"\nПериод: {start_date or 'начало'} - {end_date or 'конец'}")
            print(f"Количество возвратов: {len(returns)}")
            print(f"Количество возвращенных товаров: {total_items}")
            print(f"Общая сумма возвратов: {total_returns:.2f} руб.")
            
            product_stats = defaultdict(lambda: {'quantity': 0, 'amount': 0})
            for ret in returns:
                for item in ret['data']['returned_items']:
                    product = item['product']
                    product_stats[product['name']]['quantity'] += item['quantity']
                    product_stats[product['name']]['amount'] += product['price'] * item['quantity']
            
            if product_stats:
                print("\nЧаще всего возвращаемые товары:")
                for product in sorted(product_stats.items(), key=lambda x: -x[1]['quantity'])[:5]:
                    print(f"{product[0]}: {product[1]['quantity']} шт. на сумму {product[1]['amount']:.2f} руб.")
            
            export = input("\nЭкспортировать в CSV (да/нет)? ").lower()
            if export == 'да':
                filename = filedialog.asksaveasfilename(
                    defaultextension=".csv",
                    filetypes=[("CSV files", "*.csv")],
                    title="Сохранить отчет как"
                )
                if filename:
                    with open(filename, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f, delimiter=';')
                        writer.writerow(['Дата', 'Номер возврата', 'Оригинальный чек', 'Кол-во товаров', 'Сумма', 'Способ возврата'])
                        for ret in returns:
                            writer.writerow([
                                ret['data']['date'],
                                ret.get('receipt_id', 'N/A'),
                                ret['data']['original_receipt'],
                                len(ret['data']['returned_items']),
                                ret['data']['amount'],
                                ret['data']['payment_method']
                            ])
                    print(f"Отчет сохранен как {filename}")
        
        except Exception as e:
            print(f"Ошибка при генерации отчета: {str(e)}")
    
    @staticmethod
    def generate_products_report():
        print("\n=== ОТЧЕТ ПО ТОВАРАМ ===")
        
        products = ProductSystem.get_products()
        if not products:
            print("Нет данных о товарах!")
            return
        
        print("\nВсего товаров:", len(products))
        
        if CONFIG['inventory_enabled']:
            total_quantity = sum(p.get('quantity', 0) for p in products)
            total_value = sum(p.get('quantity', 0) * p['price'] for p in products)
            print(f"Общее количество на складе: {total_quantity}")
            print(f"Общая стоимость товаров: {total_value:.2f} руб.")
            
            out_of_stock = [p for p in products if p.get('quantity', 0) <= 0]
            if out_of_stock:
                print("\nНет в наличии:")
                for product in out_of_stock:
                    print(f"- {product['name']} (код: {product['code']})")
            
            low_stock = [p for p in products if 0 < p.get('quantity', 0) <= 3]
            if low_stock:
                print("\nЗаканчиваются (меньше 3 шт.):")
                for product in low_stock:
                    print(f"- {product['name']} (код: {product['code']}), осталось: {product.get('quantity', 0)}")
        
        export = input("\nЭкспортировать в CSV (да/нет)? ").lower()
        if export == 'да':
            filename = filedialog.asksaveasfilename(
                defaultextension=".csv",
                filetypes=[("CSV files", "*.csv")],
                title="Сохранить отчет как"
            )
            if filename:
                with open(filename, 'w', newline='', encoding='utf-8') as f:
                    writer = csv.writer(f, delimiter=';')
                    writer.writerow(['Код', 'Название', 'Цена', 'Количество', 'Стоимость'])
                    for product in products:
                        quantity = product.get('quantity', 'N/A') if CONFIG['inventory_enabled'] else 'N/A'
                        value = product.get('quantity', 0) * product['price'] if CONFIG['inventory_enabled'] else 'N/A'
                        writer.writerow([
                            product['code'],
                            product['name'],
                            product['price'],
                            quantity,
                            value
                        ])
                print(f"Отчет сохранен как {filename}")
    
    @staticmethod
    def generate_financial_report():
        print("\n=== ФИНАНСОВЫЙ ОТЧЕТ ===")
        
        try:
            start_date = input("Начальная дата (ДД.ММ.ГГГГ или Enter): ")
            end_date = input("Конечная дата (ДД.ММ.ГГГГ или Enter): ")
            
            history = DataManager.load_data(CONFIG['history_file'])
            
            sales = []
            returns = []
            for record in history:
                record_date = datetime.strptime(
                    record['date'] if 'date' in record else record['data']['date'], 
                    '%Y-%m-%d %H:%M:%S'
                )
                
                if start_date:
                    try:
                        start = datetime.strptime(start_date, '%d.%m.%Y')
                        if record_date < start:
                            continue
                    except ValueError:
                        print("Неверный формат начальной даты!")
                        return
                
                if end_date:
                    try:
                        end = datetime.strptime(end_date, '%d.%m.%Y') + timedelta(days=1)
                        if record_date >= end:
                            continue
                    except ValueError:
                        print("Неверный формат конечной даты!")
                        return
                
                if record.get('type') == 'return':
                    returns.append(record)
                else:
                    sales.append(record)
            
            total_sales = sum(s['total'] for s in sales)
            total_returns = sum(r['data']['amount'] for r in returns)
            net_income = total_sales - total_returns
            
            print(f"\nПериод: {start_date or 'начало'} - {end_date or 'конец'}")
            print(f"Общее количество продаж: {len(sales)}")
            print(f"Общая сумма продаж: {total_sales:.2f} руб.")
            print(f"Общее количество возвратов: {len(returns)}")
            print(f"Общая сумма возвратов: {total_returns:.2f} руб.")
            print(f"Чистый доход: {net_income:.2f} руб.")
            
            payment_methods = defaultdict(float)
            for sale in sales:
                payment_methods[sale['payment_method']] += sale['total']
            
            print("\nРаспределение по способам оплаты:")
            for method, amount in payment_methods.items():
                print(f"- {method}: {amount:.2f} руб. ({amount / total_sales * 100:.1f}%)")
            
            export = input("\nЭкспортировать в CSV (да/нет)? ").lower()
            if export == 'да':
                filename = filedialog.asksaveasfilename(
                    defaultextension=".csv",
                    filetypes=[("CSV files", "*.csv")],
                    title="Сохранить отчет как"
                )
                if filename:
                    with open(filename, 'w', newline='', encoding='utf-8') as f:
                        writer = csv.writer(f, delimiter=';')
                        writer.writerow(['Показатель', 'Значение'])
                        writer.writerow(['Период', f"{start_date or 'начало'} - {end_date or 'конец'}"])
                        writer.writerow(['Количество продаж', len(sales)])
                        writer.writerow(['Сумма продаж', total_sales])
                        writer.writerow(['Количество возвратов', len(returns)])
                        writer.writerow(['Сумма возвратов', total_returns])
                        writer.writerow(['Чистый доход', net_income])
                        
                        writer.writerow([])
                        writer.writerow(['Способ оплаты', 'Сумма', 'Доля'])
                        for method, amount in payment_methods.items():
                            writer.writerow([method, amount, f"{amount / total_sales * 100:.1f}%"])
                    print(f"Отчет сохранен как {filename}")
        
        except Exception as e:
            print(f"Ошибка при генерации отчета: {str(e)}")

class AdminPanel:
    @staticmethod
    def authenticate():
        password = getpass("Введите пароль администратора: ")
        hashed = hashlib.sha256(password.encode()).hexdigest()
        return hashed == CONFIG['admin_password_hash']
    
    @staticmethod
    def show_menu():
        if not AdminPanel.authenticate():
            print("\nНеверный пароль!")
            return
        
        while True:
            print("\n=== АДМИНИСТРАТОРСКАЯ ПАНЕЛЬ ===")
            print("1. Управление картами")
            print("2. Управление товарами")
            print("3. История покупок")
            print("4. Возвраты")
            print("5. Отчеты")
            print("6. Резервное копирование")
            print("7. Настройки")
            print("8. Выход")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                AdminPanel.manage_cards()
            elif choice == '2':
                AdminPanel.manage_products()
            elif choice == '3':
                AdminPanel.view_history()
            elif choice == '4':
                ReturnSystem.return_purchase()
                input("\nНажмите Enter чтобы продолжить...")
            elif choice == '5':
                ReportSystem.generate_report()
                input("\nНажмите Enter чтобы продолжить...")
            elif choice == '6':
                DataManager.backup()
                input("\nНажмите Enter чтобы продолжить...")
            elif choice == '7':
                AdminPanel.manage_settings()
            elif choice == '8':
                break
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def manage_cards():
        while True:
            cards = CardSystem.get_cards()
            
            print("\n=== УПРАВЛЕНИЕ КАРТАМИ ===")
            print("1. Просмотреть все карты")
            print("2. Добавить карту")
            print("3. Удалить карту")
            print("4. Пополнить баланс")
            print("5. Начислить бонусы")
            print("6. Назад")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                print("\nСПИСОК КАРТ:")
                if not cards:
                    print("Нет зарегистрированных карт")
                else:
                    for i, card in enumerate(cards, 1):
                        print(f"{i}. Тип: {card['type']}, Номер: ****{card['number'][-4:]}, "
                              f"Баланс: {card['balance']:.2f} руб., "
                              f"Бонусы: {card.get('bonuses', 0):.2f} руб., "
                              f"Создана: {card.get('created_at', 'N/A')}")
                input("\nНажмите Enter чтобы продолжить...")
            
            elif choice == '2':
                CardSystem.register_card()
            
            elif choice == '3':
                if not cards:
                    print("\nНет карт для удаления!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите карту для удаления:")
                for i, card in enumerate(cards, 1):
                    print(f"{i}. Тип: {card['type']}, ****{card['number'][-4:]}")
                
                try:
                    idx = int(input("Номер карты: ")) - 1
                    if 0 <= idx < len(cards):
                        deleted = cards.pop(idx)
                        CardSystem.save_cards(cards)
                        print(f"\nКарта ****{deleted['number'][-4:]} удалена!")
                    else:
                        print("\nНеверный номер карты!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '4':
                if not cards:
                    print("\nНет карт для пополнения!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите карту для пополнения:")
                for i, card in enumerate(cards, 1):
                    print(f"{i}. ****{card['number'][-4:]}, Баланс: {card['balance']:.2f} руб.")
                
                try:
                    idx = int(input("Номер карты: ")) - 1
                    if 0 <= idx < len(cards):
                        amount = float(input("Сумма пополнения: "))
                        if amount > 0:
                            cards[idx]['balance'] += amount
                            CardSystem.save_cards(cards)
                            print(f"\nБаланс пополнен на {amount:.2f} руб.")
                            print(f"Новый баланс: {cards[idx]['balance']:.2f} руб.")
                        else:
                            print("\nСумма должна быть положительной!")
                    else:
                        print("\nНеверный номер карты!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '5':
                if not cards:
                    print("\nНет карт для начисления бонусов!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите карту для начисления бонусов:")
                for i, card in enumerate(cards, 1):
                    print(f"{i}. ****{card['number'][-4:]}, Бонусы: {card.get('bonuses', 0):.2f} руб.")
                
                try:
                    idx = int(input("Номер карты: ")) - 1
                    if 0 <= idx < len(cards):
                        amount = float(input("Сумма бонусов: "))
                        if amount > 0:
                            cards[idx]['bonuses'] = cards[idx].get('bonuses', 0) + amount
                            CardSystem.save_cards(cards)
                            print(f"\nНачислено {amount:.2f} руб. бонусов.")
                            print(f"Теперь бонусов: {cards[idx]['bonuses']:.2f} руб.")
                        else:
                            print("\nСумма должна быть положительной!")
                    else:
                        print("\nНеверный номер карты!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '6':
                break
            
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def manage_products():
        while True:
            products = ProductSystem.get_products()
            
            print("\n=== УПРАВЛЕНИЕ ТОВАРАМИ ===")
            print("1. Просмотреть все товары")
            print("2. Добавить товар")
            print("3. Удалить товар")
            print("4. Изменить цену")
            print("5. Пополнить остатки")
            print("6. Поиск товара")
            print("7. Назад")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                print("\nСПИСОК ТОВАРОВ:")
                if not products:
                    print("Нет зарегистрированных товаров")
                else:
                    for i, product in enumerate(products, 1):
                        stock = f", Остаток: {product['quantity']}" if CONFIG['inventory_enabled'] and 'quantity' in product else ""
                        print(f"{i}. Код: {product['code']}, Название: {product['name']}, "
                              f"Цена: {product['price']:.2f} руб.{stock}, "
                              f"Добавлен: {product.get('created_at', 'N/A')}")
                input("\nНажмите Enter чтобы продолжить...")
            
            elif choice == '2':
                ProductSystem.register_product()
            
            elif choice == '3':
                if not products:
                    print("\nНет товаров для удаления!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите товар для удаления:")
                for i, product in enumerate(products, 1):
                    print(f"{i}. {product['name']} ({product['code']})")
                
                try:
                    idx = int(input("Номер товара: ")) - 1
                    if 0 <= idx < len(products):
                        deleted = products.pop(idx)
                        ProductSystem.save_products(products)
                        print(f"\nТовар '{deleted['name']}' удален!")
                    else:
                        print("\nНеверный номер товара!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '4':
                if not products:
                    print("\nНет товаров для изменения!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите товар для изменения цены:")
                for i, product in enumerate(products, 1):
                    print(f"{i}. {product['name']} - {product['price']:.2f} руб.")
                
                try:
                    idx = int(input("Номер товара: ")) - 1
                    if 0 <= idx < len(products):
                        new_price = float(input("Новая цена: "))
                        if new_price > 0:
                            products[idx]['price'] = new_price
                            ProductSystem.save_products(products)
                            print(f"\nЦена изменена на {new_price:.2f} руб.")
                        else:
                            print("\nЦена должна быть положительной!")
                    else:
                        print("\nНеверный номер товара!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '5':
                if not CONFIG['inventory_enabled']:
                    print("\nУчет остатков отключен в настройках!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                if not products:
                    print("\nНет товаров для пополнения!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите товар для пополнения остатков:")
                for i, product in enumerate(products, 1):
                    print(f"{i}. {product['name']} - текущий остаток: {product.get('quantity', 0)}")
                
                try:
                    idx = int(input("Номер товара: ")) - 1
                    if 0 <= idx < len(products):
                        quantity = float(input("Количество для добавления: "))
                        if quantity > 0:
                            products[idx]['quantity'] = products[idx].get('quantity', 0) + quantity
                            ProductSystem.save_products(products)
                            print(f"\nОстатки пополнены на {quantity}.")
                            print(f"Теперь остаток: {products[idx]['quantity']}")
                        else:
                            print("\nКоличество должно быть положительным!")
                    else:
                        print("\nНеверный номер товара!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '6':
                ProductSystem.search_products()
            
            elif choice == '7':
                break
            
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def view_history():
        history = DataManager.load_data(CONFIG['history_file'])
        
        print("\n=== ИСТОРИЯ ОПЕРАЦИЙ ===")
        if not history:
            print("История операций пуста")
            input("\nНажмите Enter чтобы продолжить...")
            return
        
        date_filter = input("Введите дату для фильтра (дД.ММ.ГГГГ или Enter для всех): ")
        type_filter = input("Тип (sale/return/all): ").lower()
        
        filtered = []
        for record in history:
            record_date = datetime.strptime(
                record['date'] if 'date' in record else record['data']['date'], 
                '%Y-%m-%d %H:%M:%S'
            ).strftime('%d.%m.%Y')
            
            if date_filter and date_filter != record_date:
                continue
            
            if type_filter == 'sale' and record.get('type') == 'return':
                continue
            if type_filter == 'return' and record.get('type') != 'return':
                continue
            
            filtered.append(record)
        
        if not filtered:
            print("Нет записей по указанным критериям")
            input("\nНажмите Enter чтобы продолжить...")
            return
        
        page = 0
        page_size = 5
        total_pages = (len(filtered) + page_size - 1) // page_size
        
        while True:
            print(f"\nСтраница {page + 1} из {total_pages}")
            for i in range(page * page_size, min((page + 1) * page_size, len(filtered))):
                record = filtered[i]
                
                if record.get('type') == 'return':
                    print(f"\n=== ВОЗВРАТ #{record.get('receipt_id', 'N/A')} ===")
                    print(f"Дата: {record['data']['date']}")
                    print(f"Оригинальный чек: #{record['data']['original_receipt']}")
                    print(f"Сумма: {record['data']['amount']:.2f} руб.")
                    print(f"Способ: {record['data']['payment_method']}")
                    
                    print("\nТОВАРЫ:")
                    for item in record['data']['returned_items']:
                        print(f"- {item['product']['name']} x{item['quantity']} - {item['product']['price']} руб.")
                else:
                    print(f"\n=== ЧЕК #{record.get('receipt_id', 'N/A')} ===")
                    print(f"Дата: {record['date']}")
                    print(f"Способ оплаты: {record['payment_method']}")
                    if 'card_number' in record:
                        print(f"Карта: ****{record['card_number'][-4:]}")
                    if 'cash_received' in record:
                        print(f"Внесено: {record['cash_received']:.2f} руб.")
                        print(f"Сдача: {record['change']:.2f} руб.")
                    if 'bonuses_used' in record and record['bonuses_used'] > 0:
                        print(f"Использовано бонусов: {record['bonuses_used']:.2f} руб.")
                    if 'bonus_earned' in record and record['bonus_earned'] > 0:
                        print(f"Начислено бонусов: {record['bonus_earned']:.2f} руб.")
                    
                    print("\nТОВАРЫ:")
                    for item in record['items']:
                        print(f"- {item['product']['name']} x{item['quantity']} - {item['product']['price']} руб.")
                    
                    print(f"\nИТОГО: {record['total']:.2f} руб.")
                print("-" * 40)
            
            print("\nn - следующая, p - предыдущая, q - выход")
            cmd = input("Команда: ").lower()
            
            if cmd == 'n' and page < total_pages - 1:
                page += 1
            elif cmd == 'p' and page > 0:
                page -= 1
            elif cmd == 'q':
                break
            else:
                print("Неверная команда!")
    
    @staticmethod
    def manage_settings():
        while True:
            print("\n=== НАСТРОЙКИ СИСТЕМЫ ===")
            print(f"1. Порог для скидки: {CONFIG['discount_threshold']} руб.")
            print(f"2. Размер скидки: {CONFIG['discount_percent']}%")
            print(f"3. Порог для PIN-кода: {CONFIG['pin_required_threshold']} руб.")
            print(f"4. Процент бонусов: {CONFIG['bonus_percent']}%")
            print(f"5. Учет остатков: {'Включен' if CONFIG['inventory_enabled'] else 'Выключен'}")
            print(f"6. Язык интерфейса: {CONFIG['language'].upper()}")
            print("7. Сменить пароль администратора")
            print("8. Назад")
            
            choice = input("Выберите параметр для изменения: ")
            
            if choice == '1':
                try:
                    value = float(input("Новый порог для скидки: "))
                    if value >= 0:
                        CONFIG['discount_threshold'] = value
                        print("Порог скидки обновлен!")
                    else:
                        print("Значение должно быть положительным!")
                except ValueError:
                    print("Неверное значение!")
            
            elif choice == '2':
                try:
                    value = float(input("Новый размер скидки (%): "))
                    if 0 <= value <= 100:
                        CONFIG['discount_percent'] = value
                        print("Размер скидки обновлен!")
                    else:
                        print("Значение должно быть от 0 до 100!")
                except ValueError:
                    print("Неверное значение!")
            
            elif choice == '3':
                try:
                    value = float(input("Новый порог для PIN-кода: "))
                    if value >= 0:
                        CONFIG['pin_required_threshold'] = value
                        print("Порог для PIN-кода обновлен!")
                    else:
                        print("Значение должно быть положительным!")
                except ValueError:
                    print("Неверное значение!")
            
            elif choice == '4':
                try:
                    value = float(input("Новый процент бонусов: "))
                    if 0 <= value <= 100:
                        CONFIG['bonus_percent'] = value
                        print("Процент бонусов обновлен!")
                    else:
                        print("Значение должно быть от 0 до 100!")
                except ValueError:
                    print("Неверное значение!")
            
            elif choice == '5':
                CONFIG['inventory_enabled'] = not CONFIG['inventory_enabled']
                print(f"Учет остатков {'включен' if CONFIG['inventory_enabled'] else 'выключен'}!")
            
            elif choice == '6':
                print("Доступные языки: ru, en")
                lang = input("Выберите язык: ").lower()
                if lang in LANGUAGES:
                    CONFIG['language'] = lang
                    print("Язык изменен!")
                else:
                    print("Неверный язык!")
            
            elif choice == '7':
                current = getpass("Текущий пароль: ")
                if hashlib.sha256(current.encode()).hexdigest() != CONFIG['admin_password_hash']:
                    print("Неверный пароль!")
                else:
                    new_pass = getpass("Новый пароль: ")
                    confirm = getpass("Подтвердите пароль: ")
                    if new_pass == confirm:
                        CONFIG['admin_password_hash'] = hashlib.sha256(new_pass.encode()).hexdigest()
                        print("Пароль успешно изменен!")
                    else:
                        print("Пароли не совпадают!")
            
            elif choice == '8':
                return
            
            else:
                print("Неверный выбор!")

def shopping_mode(cart):
    while True:
        print("\n=== РЕЖИМ ПОКУПОК ===")
        print("1. Сканировать товар")
        print("2. Просмотреть корзину")
        print("3. Оплатить")
        print("4. Очистить корзину")
        print("5. Вернуться в меню")
        
        choice = input("Выберите действие: ")
        
        if choice == '1':
            Scanner.scan_product(cart)
        elif choice == '2':
            cart.edit_interactive()
        elif choice == '3':
            PaymentSystem.process_payment(cart)
        elif choice == '4':
            cart.clear()
            input("Нажмите Enter чтобы продолжить...")
        elif choice == '5':
            return
        else:
            print("Неверный выбор!")

def main_menu():
    cart = ShoppingCart()
    init_files()
    
    # Загрузка счетчика чеков
    history = DataManager.load_data(CONFIG['history_file'])
    receipt_numbers = [int(r['receipt_id'][1:]) for r in history if 'receipt_id' in r and r['receipt_id'].startswith('R')]
    if receipt_numbers:
        CONFIG['receipt_counter'] = max(receipt_numbers)
    
    while True:
        print(f"\n{Translator.translate('main_menu')}")
        print(f"1. {Translator.translate('shopping')}")
        print(f"2. {Translator.translate('admin')}")
        print(f"3. {Translator.translate('exit')}")
        
        choice = input(Translator.translate('choose_option'))
        
        if choice == '1':
            shopping_mode(cart)
        elif choice == '2':
            AdminPanel.show_menu()
        elif choice == '3':
            print("\nДо свидания!")
            break
        else:
            print("Неверный выбор!")

def init_files():
    os.makedirs(CONFIG['data_dir'], exist_ok=True)
    os.makedirs(CONFIG['backup_dir'], exist_ok=True)
    
    for file in [CONFIG['cards_file'], CONFIG['products_file'], CONFIG['history_file']]:
        path = os.path.join(CONFIG['data_dir'], file)
        if not os.path.exists(path):
            with open(path, 'w', encoding='utf-8') as f:
                if file.endswith('.json'):
                    json.dump([], f)

if __name__ == "__main__":
    main_menu()