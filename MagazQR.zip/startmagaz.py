import os
import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar
from datetime import datetime
import qrcode
import shutil
from tkinter import messagebox
import tkinter as tk
import time

# Конфигурация файлов
CARDS_FILE = "cartochka.txt"
PRODUCTS_FILE = "tovar.txt"
PURCHASE_HISTORY = "purchase_history.txt"
BACKUP_DIR = "backup"
ADMIN_PASSWORD = "admin123"

class ShoppingCart:
    def __init__(self):
        self.items = []
        self.total = 0
        self.discount = 0
    
    def add_item(self, product):
        self.items.append(product)
        self.total += product['price']
        print(f"Добавлено: {product['name']} - {product['price']} руб.")
    
    def remove_item(self, index):
        if 0 <= index < len(self.items):
            removed = self.items.pop(index)
            self.total -= removed['price']
            print(f"Удалено: {removed['name']}")
            self.calculate_discount()
    
    def clear(self):
        self.items = []
        self.total = 0
        self.discount = 0
    
    def show(self):
        if not self.items:
            print("\nКорзина пуста!")
            return
        
        print("\n=== Ваша корзина ===")
        for i, item in enumerate(self.items, 1):
            print(f"{i}. {item['name']} - {item['price']} руб.")
        
        if self.discount > 0:
            print(f"\nСкидка 10%: -{self.discount:.2f} руб.")
        print(f"Итого: {self.get_total():.2f} руб.")
    
    def calculate_discount(self):
        self.discount = self.total * 0.1 if self.total >= 500 else 0
    
    def get_total(self):
        return self.total - self.discount

def init_files():
    """Инициализация необходимых файлов"""
    os.makedirs(BACKUP_DIR, exist_ok=True)
    for file in [CARDS_FILE, PRODUCTS_FILE, PURCHASE_HISTORY]:
        if not os.path.exists(file):
            open(file, 'w').close()

# Функции работы с данными
def read_cards():
    cards = []
    if os.path.exists(CARDS_FILE):
        with open(CARDS_FILE, 'r') as f:
            for line in f:
                if line.strip():
                    try:
                        card_data = eval(line.strip())
                        if len(card_data) == 3:
                            cards.append({
                                'number': card_data[0],
                                'pin': card_data[1],
                                'balance': card_data[2]
                            })
                    except:
                        continue
    return cards

def read_products():
    products = []
    if os.path.exists(PRODUCTS_FILE):
        with open(PRODUCTS_FILE, 'r') as f:
            for line in f:
                if line.strip():
                    try:
                        product_data = eval(line.strip())
                        if len(product_data) == 3:
                            products.append({
                                'code': product_data[0],
                                'name': product_data[1],
                                'price': product_data[2]
                            })
                    except:
                        continue
    return products

def write_cards(cards):
    with open(CARDS_FILE, 'w') as f:
        for card in cards:
            f.write(f"[ {card['number']}, {card['pin']}, {card['balance']} ]\n")

def write_products(products):
    with open(PRODUCTS_FILE, 'w') as f:
        for product in products:
            f.write(f"[ {product['code']}, '{product['name']}', {product['price']} ]\n")

def save_purchase(card_number, items, total):
    with open(PURCHASE_HISTORY, 'a', encoding='utf-8') as f:
        f.write(f"{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
        f.write(f"Карта: ****{str(card_number)[-4:]}\n")
        for item in items:
            f.write(f"{item['name']} - {item['price']} руб.\n")
        f.write(f"Итого: {total:.2f} руб.\n\n")

# Основные функции программы
def scan_qr_code(cart):
    cap = cv2.VideoCapture(0)
    last_scan_time = 0
    
    while True:
        _, frame = cap.read()
        
        decoded_objects = pyzbar.decode(frame)
        current_time = time.time()
        
        for obj in decoded_objects:
            if current_time - last_scan_time < 1.0:
                continue
                
            last_scan_time = current_time
            data = obj.data.decode('utf-8')
            
            try:
                if data.startswith('[') and data.endswith(']'):
                    data_list = eval(data)
                    if (len(data_list) == 3 and isinstance(data_list[0], int) 
                            and isinstance(data_list[1], str) 
                            and isinstance(data_list[2], (int, float))):
                        
                        product = {
                            'code': data_list[0],
                            'name': data_list[1],
                            'price': data_list[2]
                        }
                        cart.add_item(product)
                        cart.calculate_discount()
            except Exception as e:
                print(f"Ошибка обработки QR-кода: {e}")
        
        cv2.imshow("Сканер QR-кодов (ESC - выход)", frame)
        
        if cv2.waitKey(1) == 27:
            break
    
    cap.release()
    cv2.destroyAllWindows()

def process_payment(cart):
    if not cart.items:
        print("\nКорзина пуста!")
        return
    
    cards = read_cards()
    if not cards:
        print("\nНет доступных карт!")
        return
    
    print("\n=== Оплата ===")
    cart.show()
    
    print("\nДоступные карты:")
    for i, card in enumerate(cards, 1):
        print(f"{i}. Карта: ****{str(card['number'])[-4:]}, Баланс: {card['balance']} руб.")
    
    try:
        choice = int(input("\nВыберите карту: ")) - 1
        if 0 <= choice < len(cards):
            card = cards[choice]
            total = cart.get_total()
            
            if total > card['balance']:
                print("\nНедостаточно средств на карте!")
                return
            
            if total > 100:
                pin = input("Введите PIN-код: ")
                if pin != str(card['pin']):
                    print("\nНеверный PIN-код!")
                    return
            
            # Обновляем баланс
            cards[choice]['balance'] -= total
            write_cards(cards)
            
            # Сохраняем чек
            save_purchase(card['number'], cart.items, total)
            show_receipt(card['number'], cart.items, total, card['balance'] - total)
            
            cart.clear()
        else:
            print("\nНеверный выбор карты!")
    except ValueError:
        print("\nОшибка ввода!")

def show_receipt(card_number, items, total, new_balance):
    root = tk.Tk()
    root.withdraw()
    
    receipt = "=== ЧЕК ===\n\n"
    receipt += f"Дата: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}\n"
    receipt += f"Карта: ****{str(card_number)[-4:]}\n\n"
    
    for item in items:
        receipt += f"{item['name']:20} {item['price']:>6.2f} руб.\n"
    
    receipt += f"\n{'Итого:':20} {total:>6.2f} руб.\n"
    receipt += f"{'Остаток:':20} {new_balance:>6.2f} руб.\n"
    receipt += "\nСпасибо за покупку!"
    
    messagebox.showinfo("Чек", receipt)
    root.destroy()

# Администраторские функции
def admin_panel():
    if input("\nПароль: ") != ADMIN_PASSWORD:
        print("\nНеверный пароль!")
        return
    
    while True:
        print("\n=== АДМИНИСТРАТОР ===")
        print("1. Управление картами")
        print("2. Управление товарами")
        print("3. История покупок")
        print("4. Резервное копирование")
        print("5. Выход")
        
        choice = input("Выберите: ")
        
        if choice == '1':
            manage_cards()
        elif choice == '2':
            manage_products()
        elif choice == '3':
            view_purchase_history()
        elif choice == '4':
            backup_data()
        elif choice == '5':
            return
        else:
            print("\nНеверный выбор!")

def manage_cards():
    while True:
        cards = read_cards()
        
        print("\n=== КАРТЫ ===")
        print("1. Просмотреть все")
        print("2. Добавить карту")
        print("3. Удалить карту")
        print("4. Назад")
        
        choice = input("Выберите: ")
        
        if choice == '1':
            print("\nСписок карт:")
            for i, card in enumerate(cards, 1):
                print(f"{i}. ****{str(card['number'])[-4:]}, PIN: {card['pin']}, Баланс: {card['balance']} руб.")
        
        elif choice == '2':
            register_card()
        
        elif choice == '3':
            if cards:
                print("\nВыберите карту для удаления:")
                for i, card in enumerate(cards, 1):
                    print(f"{i}. ****{str(card['number'])[-4:]}")
                
                try:
                    choice = int(input("Номер: ")) - 1
                    if 0 <= choice < len(cards):
                        del cards[choice]
                        write_cards(cards)
                        print("\nКарта удалена!")
                except ValueError:
                    print("\nОшибка ввода!")
            else:
                print("\nНет карт для удаления!")
        
        elif choice == '4':
            return
        
        else:
            print("\nНеверный выбор!")

def manage_products():
    while True:
        products = read_products()
        
        print("\n=== ТОВАРЫ ===")
        print("1. Просмотреть все")
        print("2. Добавить товар")
        print("3. Удалить товар")
        print("4. Назад")
        
        choice = input("Выберите: ")
        
        if choice == '1':
            print("\nСписок товаров:")
            for i, product in enumerate(products, 1):
                print(f"{i}. {product['code']}: {product['name']} - {product['price']} руб.")
        
        elif choice == '2':
            register_product()
        
        elif choice == '3':
            if products:
                print("\nВыберите товар для удаления:")
                for i, product in enumerate(products, 1):
                    print(f"{i}. {product['name']}")
                
                try:
                    choice = int(input("Номер: ")) - 1
                    if 0 <= choice < len(products):
                        del products[choice]
                        write_products(products)
                        print("\nТовар удален!")
                except ValueError:
                    print("\nОшибка ввода!")
            else:
                print("\nНет товаров для удаления!")
        
        elif choice == '4':
            return
        
        else:
            print("\nНеверный выбор!")

def view_purchase_history():
    if os.path.exists(PURCHASE_HISTORY):
        print("\n=== ИСТОРИЯ ПОКУПОК ===")
        with open(PURCHASE_HISTORY, 'r', encoding='utf-8') as f:
            print(f.read())
    else:
        print("\nИстория покупок пуста!")

def backup_data():
    date_str = datetime.now().strftime("%Y%m%d_%H%M%S")
    try:
        shutil.copy2(CARDS_FILE, os.path.join(BACKUP_DIR, f"cards_{date_str}.bak"))
        shutil.copy2(PRODUCTS_FILE, os.path.join(BACKUP_DIR, f"products_{date_str}.bak"))
        shutil.copy2(PURCHASE_HISTORY, os.path.join(BACKUP_DIR, f"history_{date_str}.bak"))
        print("\nРезервная копия создана!")
    except Exception as e:
        print(f"\nОшибка при создании резервной копии: {e}")

# Функции регистрации
def register_card():
    print("\n=== РЕГИСТРАЦИЯ КАРТЫ ===")
    while True:
        number = input("Номер карты (16 цифр): ").strip()
        if len(number) != 16 or not number.isdigit():
            print("Номер должен содержать 16 цифр!")
            continue
        
        pin = input("PIN-код (4 цифры): ").strip()
        if len(pin) != 4 or not pin.isdigit():
            print("PIN должен содержать 4 цифры!")
            continue
        
        try:
            balance = float(input("Начальный баланс: "))
            if balance < 0:
                print("Баланс не может быть отрицательным!")
                continue
            
            cards = read_cards()
            cards.append({
                'number': number,
                'pin': pin,
                'balance': balance
            })
            write_cards(cards)
            
            # Генерация QR-кода
            generate_qr_code([number, pin, balance], f"card_{number[-4:]}.png")
            print(f"\nКарта зарегистрирована! QR-код сохранен как card_{number[-4:]}.png")
            return
        except ValueError:
            print("Неверная сумма баланса!")

def register_product():
    print("\n=== РЕГИСТРАЦИЯ ТОВАРА ===")
    while True:
        try:
            code = int(input("Код товара: "))
            name = input("Название: ").strip()
            price = float(input("Цена: "))
            
            if price <= 0:
                print("Цена должна быть положительной!")
                continue
            
            products = read_products()
            products.append({
                'code': code,
                'name': name,
                'price': price
            })
            write_products(products)
            
            # Генерация QR-кода
            generate_qr_code([code, name, price], f"product_{code}.png")
            print(f"\nТовар зарегистрирован! QR-код сохранен как product_{code}.png")
            return
        except ValueError:
            print("Неверный формат данных!")

def generate_qr_code(data, filename):
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(str(data))
    qr.make(fit=True)
    img = qr.make_image(fill_color="black", back_color="white")
    img.save(filename)

# Главное меню
def show_menu():
    cart = ShoppingCart()
    init_files()
    
    while True:
        print("\n=== ГЛАВНОЕ МЕНЮ ===")
        print("1. Магазин")
        print("2. Администратор")
        print("3. Выход")
        
        choice = input("Выберите: ")
        
        if choice == '1':
            shopping_mode(cart)
        elif choice == '2':
            admin_panel()
        elif choice == '3':
            print("\nДо свидания!")
            break
        else:
            print("\nНеверный выбор!")

def shopping_mode(cart):
    while True:
        print("\n=== МАГАЗИН ===")
        print("1. Сканировать товар")
        print("2. Корзина")
        print("3. Оплатить")
        print("4. Очистить корзину")
        print("5. Назад")
        
        choice = input("Выберите: ")
        
        if choice == '1':
            scan_qr_code(cart)
        elif choice == '2':
            cart.show()
        elif choice == '3':
            process_payment(cart)
        elif choice == '4':
            cart.clear()
            print("\nКорзина очищена!")
        elif choice == '5':
            return
        else:
            print("\nНеверный выбор!")

if __name__ == "__main__":
    show_menu()