import os
import cv2
import time
import json
from pyzbar import pyzbar
from datetime import datetime
import qrcode
import shutil
from tkinter import messagebox, simpledialog
import tkinter as tk
import hashlib
from getpass import getpass
import sys

# Конфигурация
CONFIG = {
    'data_dir': 'data',
    'cards_file': 'cards.json',
    'products_file': 'products.json',
    'history_file': 'history.json',
    'backup_dir': 'backups',
    'admin_password_hash': '5e884898da28047151d0e56f8dc6292773603d0d6aabbdd62a11ef721d1542d8',  # sha256('password')
    'discount_threshold': 500,
    'discount_percent': 10,
    'pin_required_threshold': 100
}

# Инициализация файлов
def init_files():
    os.makedirs(CONFIG['data_dir'], exist_ok=True)
    os.makedirs(CONFIG['backup_dir'], exist_ok=True)
    
    for file in [CONFIG['cards_file'], CONFIG['products_file'], CONFIG['history_file']]:
        path = os.path.join(CONFIG['data_dir'], file)
        if not os.path.exists(path):
            with open(path, 'w', encoding='utf-8') as f:
                if file.endswith('.json'):
                    json.dump([], f)

# Класс корзины с улучшенным функционалом
class ShoppingCart:
    def __init__(self):
        self.items = []
        self.total = 0
        self.discount = 0
        self.scanned_codes = set()
    
    def add_item(self, product, quantity=1):
        if quantity <= 0:
            return False
        
        existing = next((item for item in self.items if item['product']['code'] == product['code']), None)
        
        if existing:
            existing['quantity'] += quantity
            print(f"Количество {product['name']} увеличено до {existing['quantity']}")
        else:
            self.items.append({
                'product': product,
                'quantity': quantity,
                'added_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            })
            self.scanned_codes.add(product['code'])
            print(f"Добавлено: {product['name']} x{quantity}")
        
        self.calculate_totals()
        return True
    
    def remove_item(self, index):
        if 0 <= index < len(self.items):
            removed = self.items.pop(index)
            self.scanned_codes.remove(removed['product']['code'])
            print(f"Удалено: {removed['product']['name']}")
            self.calculate_totals()
            return True
        return False
    
    def update_quantity(self, index, new_quantity):
        if 0 <= index < len(self.items) and new_quantity > 0:
            self.items[index]['quantity'] = new_quantity
            self.calculate_totals()
            return True
        elif new_quantity == 0:
            return self.remove_item(index)
        return False
    
    def calculate_totals(self):
        self.total = sum(item['product']['price'] * item['quantity'] for item in self.items)
        self.discount = (self.total * CONFIG['discount_percent'] / 100 
                        if self.total >= CONFIG['discount_threshold'] else 0)
    
    def get_final_total(self):
        return round(self.total - self.discount, 2)
    
    def clear(self):
        self.items = []
        self.scanned_codes = set()
        self.total = 0
        self.discount = 0
        print("Корзина очищена")
    
    def display(self):
        if not self.items:
            print("\nКорзина пуста")
            return False
        
        print("\n=== ВАША КОРЗИНА ===")
        for i, item in enumerate(self.items, 1):
            p = item['product']
            print(f"{i}. {p['name']} ({p['code']}) - {p['price']} руб. x{item['quantity']} = {p['price'] * item['quantity']} руб.")
        
        if self.discount > 0:
            print(f"\nСкидка {CONFIG['discount_percent']}%: -{self.discount:.2f} руб.")
        print(f"ИТОГО: {self.get_final_total():.2f} руб.")
        return True
    
    def edit_interactive(self):
        while True:
            if not self.display():
                return
            
            print("\n1. Изменить количество")
            print("2. Удалить товар")
            print("3. Вернуться")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                try:
                    idx = int(input("Номер товара: ")) - 1
                    if 0 <= idx < len(self.items):
                        new_qty = int(input(f"Новое количество (текущее: {self.items[idx]['quantity']}): "))
                        if not self.update_quantity(idx, new_qty):
                            print("Неверное количество!")
                    else:
                        print("Неверный номер товара!")
                except ValueError:
                    print("Ошибка ввода!")
            
            elif choice == '2':
                try:
                    idx = int(input("Номер товара для удаления: ")) - 1
                    if not self.remove_item(idx):
                        print("Неверный номер товара!")
                except ValueError:
                    print("Ошибка ввода!")
            
            elif choice == '3':
                return
            
            else:
                print("Неверный выбор!")

# Система работы с данными
class DataManager:
    @staticmethod
    def load_data(filename):
        path = os.path.join(CONFIG['data_dir'], filename)
        try:
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
        except (FileNotFoundError, json.JSONDecodeError):
            return []
    
    @staticmethod
    def save_data(filename, data):
        path = os.path.join(CONFIG['data_dir'], filename)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
    
    @staticmethod
    def backup():
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        os.makedirs(CONFIG['backup_dir'], exist_ok=True)
        
        for file in [CONFIG['cards_file'], CONFIG['products_file'], CONFIG['history_file']]:
            src = os.path.join(CONFIG['data_dir'], file)
            dst = os.path.join(CONFIG['backup_dir'], f"{timestamp}_{file}")
            if os.path.exists(src):
                shutil.copy2(src, dst)
        
        print(f"\nСоздана резервная копия {timestamp}")

# Функции для работы с картами
class CardSystem:
    @staticmethod
    def get_cards():
        return DataManager.load_data(CONFIG['cards_file'])
    
    @staticmethod
    def save_cards(cards):
        DataManager.save_data(CONFIG['cards_file'], cards)
    
    @staticmethod
    def register_card():
        print("\n=== РЕГИСТРАЦИЯ КАРТЫ ===")
        
        # Выбор типа карты
        print("1. Стандартная карта")
        print("2. QR-карта")
        card_type = input("Выберите тип: ")
        
        if card_type not in ['1', '2']:
            print("Неверный выбор!")
            return
        
        card_type = 'standard' if card_type == '1' else 'qr'
        
        # Ввод данных
        while True:
            number = input("Номер карты (16 цифр): ").strip()
            if len(number) != 16 or not number.isdigit():
                print("Номер должен содержать 16 цифр!")
                continue
            
            pin = getpass("PIN-код (4 цифры): ")
            if len(pin) != 4 or not pin.isdigit():
                print("PIN должен содержать 4 цифры!")
                continue
            
            try:
                balance = float(input("Начальный баланс: "))
                if balance < 0:
                    print("Баланс не может быть отрицательным!")
                    continue
                break
            except ValueError:
                print("Неверная сумма!")
        
        # Создание карты
        cards = CardSystem.get_cards()
        new_card = {
            'number': number,
            'pin': pin,
            'balance': balance,
            'type': card_type,
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        }
        
        # Для QR-карт генерируем QR-код
        if card_type == 'qr':
            qr_data = json.dumps([number, pin[:2] + '**', balance, 'qr'])
            qr = qrcode.QRCode(version=1, box_size=10, border=4)
            qr.add_data(qr_data)
            qr.make(fit=True)
            img = qr.make_image(fill_color="black", back_color="white")
            filename = f"qr_card_{number[-4:]}.png"
            img.save(filename)
            print(f"\nQR-код сохранен как {filename}")
        
        cards.append(new_card)
        CardSystem.save_cards(cards)
        print("\nКарта успешно зарегистрирована!")

# Функции для работы с товарами
class ProductSystem:
    @staticmethod
    def get_products():
        return DataManager.load_data(CONFIG['products_file'])
    
    @staticmethod
    def save_products(products):
        DataManager.save_data(CONFIG['products_file'], products)
    
    @staticmethod
    def register_product():
        print("\n=== РЕГИСТРАЦИЯ ТОВАРА ===")
        
        while True:
            try:
                code = int(input("Код товара: "))
                name = input("Название: ").strip()
                if not name:
                    raise ValueError
                
                price = float(input("Цена: "))
                if price <= 0:
                    print("Цена должна быть положительной!")
                    continue
                
                break
            except ValueError:
                print("Неверные данные!")
        
        products = ProductSystem.get_products()
        products.append({
            'code': code,
            'name': name,
            'price': price,
            'created_at': datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        })
        
        # Генерация QR-кода
        qr_data = json.dumps([code, name, price])
        qr = qrcode.QRCode(version=1, box_size=10, border=4)
        qr.add_data(qr_data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        filename = f"product_{code}.png"
        img.save(filename)
        print(f"\nQR-код сохранен как {filename}")
        
        ProductSystem.save_products(products)
        print("\nТовар успешно зарегистрирован!")

# Система сканирования
class Scanner:
    @staticmethod
    def scan_product(cart):
        cap = None
        try:
            cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not cap.isOpened():
                print("\nОшибка: Камера недоступна")
                return
            
            print("\n=== РЕЖИМ СКАНИРОВАНИЯ ===")
            print("Наведите камеру на QR-код товара")
            print("ESC - выход, SPACE - вручную")
            
            last_scan = 0
            while True:
                ret, frame = cap.read()
                if not ret:
                    print("Ошибка получения изображения")
                    break
                
                # Пытаемся декодировать QR-код
                current_time = time.time()
                if current_time - last_scan > 1:  # Защита от двойного сканирования
                    try:
                        decoded = pyzbar.decode(frame)
                        for obj in decoded:
                            data = obj.data.decode('utf-8')
                            if data.startswith('[') and data.endswith(']'):
                                product_data = json.loads(data)
                                if len(product_data) >= 3:
                                    product = {
                                        'code': product_data[0],
                                        'name': product_data[1],
                                        'price': product_data[2]
                                    }
                                    
                                    try:
                                        qty = int(input(f"\nВведите количество для {product['name']} (по умолчанию 1): ") or 1)
                                        if cart.add_item(product, qty):
                                            last_scan = current_time
                                            cv2.rectangle(frame, (0, 0), (frame.shape[1], frame.shape[0]), (0, 255, 0), 10)
                                            print(f"Добавлено: {product['name']} x{qty}")
                                    except ValueError:
                                        print("Используется количество 1")
                                        if cart.add_item(product, 1):
                                            last_scan = current_time
                                            cv2.rectangle(frame, (0, 0), (frame.shape[1], frame.shape[0]), (0, 255, 0), 10)
                    except Exception as e:
                        # Игнорируем ошибки сканирования
                        pass
                
                cv2.imshow('Сканер (ESC - выход)', frame)
                
                key = cv2.waitKey(1)
                if key == 27:  # ESC
                    break
                elif key == 32:  # SPACE
                    code = input("\nВведите код товара вручную: ")
                    name = input("Название товара: ")
                    try:
                        price = float(input("Цена: "))
                        qty = int(input("Количество: ") or 1)
                        
                        product = {
                            'code': code,
                            'name': name,
                            'price': price
                        }
                        cart.add_item(product, qty)
                    except ValueError:
                        print("Ошибка ввода данных!")
        finally:
            if cap:
                cap.release()
            cv2.destroyAllWindows()

# Система оплаты
class PaymentSystem:
    @staticmethod
    def process_payment(cart):
        if not cart.items:
            print("\nКорзина пуста!")
            return
        
        while True:
            print("\n=== ВЫБОР СПОСОБА ОПЛАТЫ ===")
            print("1. Стандартная карта")
            print("2. QR-карта")
            print("3. Наличные")
            print("4. Отмена")
            
            choice = input("Выберите способ: ")
            total = cart.get_final_total()
            
            if choice == '1':
                PaymentSystem.pay_by_standard_card(cart, total)
                break
            elif choice == '2':
                PaymentSystem.pay_by_qr_card(cart, total)
                break
            elif choice == '3':
                PaymentSystem.pay_by_cash(cart, total)
                break
            elif choice == '4':
                break
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def pay_by_standard_card(cart, total):
        cards = [c for c in CardSystem.get_cards() if c['type'] == 'standard']
        if not cards:
            print("\nНет доступных стандартных карт!")
            return
        
        print("\n=== ОПЛАТА СТАНДАРТНОЙ КАРТОЙ ===")
        cart.display()
        
        print("\nДоступные карты:")
        for i, card in enumerate(cards, 1):
            print(f"{i}. ****{card['number'][-4:]}, Баланс: {card['balance']:.2f} руб.")
        
        try:
            idx = int(input("\nВыберите карту: ")) - 1
            if 0 <= idx < len(cards):
                card = cards[idx]
                
                if total > card['balance']:
                    print("\nНедостаточно средств на карте!")
                    return
                
                if total >= CONFIG['pin_required_threshold']:
                    pin = getpass("Введите PIN-код: ")
                    if pin != card['pin']:
                        print("\nНеверный PIN-код!")
                        return
                
                # Подтверждение
                print(f"\nСумма к оплате: {total:.2f} руб.")
                confirm = input("Подтвердить оплату (да/нет): ").lower()
                if confirm != 'да':
                    print("Оплата отменена")
                    return
                
                # Списание средств
                cards[idx]['balance'] -= total
                CardSystem.save_cards(cards)
                
                # Сохранение чека
                PaymentSystem.save_receipt(
                    payment_method="Стандартная карта",
                    items=cart.items,
                    total=total,
                    card_number=card['number']
                )
                
                # Показ чека
                PaymentSystem.show_receipt(
                    items=cart.items,
                    total=total,
                    payment_method="Стандартная карта",
                    card_number=card['number']
                )
                
                # Очистка корзины
                cart.clear()
            else:
                print("Неверный номер карты!")
        except ValueError:
            print("Ошибка ввода!")
    
    @staticmethod
    def pay_by_qr_card(cart, total):
        print("\n=== ОПЛАТА QR-КАРТОЙ ===")
        print("Поднесите QR-код карты к камере...")
        
        cap = None
        try:
            cap = cv2.VideoCapture(0, cv2.CAP_DSHOW)
            if not cap.isOpened():
                print("\nОшибка: Камера недоступна")
                return
            
            cards = CardSystem.get_cards()
            qr_cards = [c for c in cards if c['type'] == 'qr']
            
            found = None
            while not found:
                ret, frame = cap.read()
                if not ret:
                    print("Ошибка получения изображения")
                    break
                
                try:
                    decoded = pyzbar.decode(frame)
                    for obj in decoded:
                        data = obj.data.decode('utf-8')
                        if data.startswith('[') and data.endswith(']'):
                            card_data = json.loads(data)
                            if len(card_data) >= 3:
                                for card in qr_cards:
                                    if str(card['number']) == str(card_data[0]):
                                        found = card
                                        break
                except:
                    pass
                
                cv2.imshow('Сканирование QR-карты (ESC - отмена)', frame)
                if cv2.waitKey(1) == 27:
                    break
            
            if found:
                if total > found['balance']:
                    print("\nНедостаточно средств на карте!")
                    return
                
                # Списание средств
                for i, card in enumerate(cards):
                    if card['number'] == found['number']:
                        cards[i]['balance'] -= total
                        break
                
                CardSystem.save_cards(cards)
                
                # Сохранение чека
                PaymentSystem.save_receipt(
                    payment_method="QR-карта",
                    items=cart.items,
                    total=total,
                    card_number=found['number']
                )
                
                # Показ чека
                PaymentSystem.show_receipt(
                    items=cart.items,
                    total=total,
                    payment_method="QR-карта",
                    card_number=found['number']
                )
                
                # Очистка корзины
                cart.clear()
            else:
                print("\nQR-карта не распознана")
        finally:
            if cap:
                cap.release()
            cv2.destroyAllWindows()
    
    @staticmethod
    def pay_by_cash(cart, total):
        print("\n=== ОПЛАТА НАЛИЧНЫМИ ===")
        cart.display()
        
        while True:
            try:
                cash = float(input("\nВнесенная сумма: "))
                if cash < total:
                    print(f"Не хватает {total - cash:.2f} руб.")
                    continue
                
                change = cash - total
                print(f"\nСдача: {change:.2f} руб.")
                
                confirm = input("Подтвердить операцию (да/нет): ").lower()
                if confirm != 'да':
                    print("Отменено")
                    return
                
                # Сохранение чека
                PaymentSystem.save_receipt(
                    payment_method="Наличные",
                    items=cart.items,
                    total=total,
                    cash_received=cash,
                    change=change
                )
                
                # Показ чека
                PaymentSystem.show_receipt(
                    items=cart.items,
                    total=total,
                    payment_method="Наличные",
                    cash_received=cash,
                    change=change
                )
                
                # Очистка корзины
                cart.clear()
                break
            except ValueError:
                print("Неверная сумма!")
    
    @staticmethod
    def save_receipt(payment_method, items, total, **kwargs):
        receipt = {
            'date': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
            'payment_method': payment_method,
            'items': [{
                'product': item['product'],
                'quantity': item['quantity'],
                'price': item['product']['price']
            } for item in items],
            'total': total,
            **kwargs
        }
        
        history = DataManager.load_data(CONFIG['history_file'])
        history.append(receipt)
        DataManager.save_data(CONFIG['history_file'], history)
    
    @staticmethod
    def show_receipt(items, total, payment_method, **kwargs):
        root = tk.Tk()
        root.withdraw()
        
        receipt = f"=== ЧЕК ===\n\n"
        receipt += f"Дата: {datetime.now().strftime('%d.%m.%Y %H:%M:%S')}\n"
        receipt += f"Способ оплаты: {payment_method}\n"
        
        if 'card_number' in kwargs:
            receipt += f"Карта: ****{kwargs['card_number'][-4:]}\n"
        if 'cash_received' in kwargs:
            receipt += f"Внесено: {kwargs['cash_received']:.2f} руб.\n"
            receipt += f"Сдача: {kwargs['change']:.2f} руб.\n"
        
        receipt += "\nТОВАРЫ:\n"
        for item in items:
            p = item['product']
            receipt += f"{p['name']:20} {p['price']:>7.2f} x{item['quantity']} = {p['price'] * item['quantity']:>7.2f} руб.\n"
        
        receipt += f"\n{'ИТОГО:':20} {total:>7.2f} руб.\n"
        receipt += "\nСпасибо за покупку!"
        
        messagebox.showinfo("Чек", receipt)

# Администраторская панель
class AdminPanel:
    @staticmethod
    def authenticate():
        password = getpass("Введите пароль администратора: ")
        hashed = hashlib.sha256(password.encode()).hexdigest()
        return hashed == CONFIG['admin_password_hash']
    
    @staticmethod
    def show_menu():
        if not AdminPanel.authenticate():
            print("\nНеверный пароль!")
            return
        
        while True:
            print("\n=== АДМИНИСТРАТОРСКАЯ ПАНЕЛЬ ===")
            print("1. Управление картами")
            print("2. Управление товарами")
            print("3. История покупок")
            print("4. Резервное копирование")
            print("5. Настройки")
            print("6. Выход")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                AdminPanel.manage_cards()
            elif choice == '2':
                AdminPanel.manage_products()
            elif choice == '3':
                AdminPanel.view_history()
            elif choice == '4':
                DataManager.backup()
                input("\nНажмите Enter чтобы продолжить...")
            elif choice == '5':
                AdminPanel.manage_settings()
            elif choice == '6':
                break
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def manage_cards():
        while True:
            cards = CardSystem.get_cards()
            
            print("\n=== УПРАВЛЕНИЕ КАРТАМИ ===")
            print("1. Просмотреть все карты")
            print("2. Добавить карту")
            print("3. Удалить карту")
            print("4. Пополнить баланс")
            print("5. Назад")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                print("\nСПИСОК КАРТ:")
                if not cards:
                    print("Нет зарегистрированных карт")
                else:
                    for i, card in enumerate(cards, 1):
                        print(f"{i}. Тип: {card['type']}, Номер: ****{card['number'][-4:]}, "
                              f"Баланс: {card['balance']:.2f} руб., "
                              f"Создана: {card.get('created_at', 'N/A')}")
                input("\nНажмите Enter чтобы продолжить...")
            
            elif choice == '2':
                CardSystem.register_card()
            
            elif choice == '3':
                if not cards:
                    print("\nНет карт для удаления!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите карту для удаления:")
                for i, card in enumerate(cards, 1):
                    print(f"{i}. Тип: {card['type']}, ****{card['number'][-4:]}")
                
                try:
                    idx = int(input("Номер карты: ")) - 1
                    if 0 <= idx < len(cards):
                        deleted = cards.pop(idx)
                        CardSystem.save_cards(cards)
                        print(f"\nКарта ****{deleted['number'][-4:]} удалена!")
                    else:
                        print("\nНеверный номер карты!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '4':
                if not cards:
                    print("\nНет карт для пополнения!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите карту для пополнения:")
                for i, card in enumerate(cards, 1):
                    print(f"{i}. ****{card['number'][-4:]}, Баланс: {card['balance']:.2f} руб.")
                
                try:
                    idx = int(input("Номер карты: ")) - 1
                    if 0 <= idx < len(cards):
                        amount = float(input("Сумма пополнения: "))
                        if amount > 0:
                            cards[idx]['balance'] += amount
                            CardSystem.save_cards(cards)
                            print(f"\nБаланс пополнен на {amount:.2f} руб.")
                            print(f"Новый баланс: {cards[idx]['balance']:.2f} руб.")
                        else:
                            print("\nСумма должна быть положительной!")
                    else:
                        print("\nНеверный номер карты!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '5':
                break
            
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def manage_products():
        while True:
            products = ProductSystem.get_products()
            
            print("\n=== УПРАВЛЕНИЕ ТОВАРАМИ ===")
            print("1. Просмотреть все товары")
            print("2. Добавить товар")
            print("3. Удалить товар")
            print("4. Изменить цену")
            print("5. Назад")
            
            choice = input("Выберите действие: ")
            
            if choice == '1':
                print("\nСПИСОК ТОВАРОВ:")
                if not products:
                    print("Нет зарегистрированных товаров")
                else:
                    for i, product in enumerate(products, 1):
                        print(f"{i}. Код: {product['code']}, Название: {product['name']}, "
                              f"Цена: {product['price']:.2f} руб., "
                              f"Добавлен: {product.get('created_at', 'N/A')}")
                input("\nНажмите Enter чтобы продолжить...")
            
            elif choice == '2':
                ProductSystem.register_product()
            
            elif choice == '3':
                if not products:
                    print("\nНет товаров для удаления!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите товар для удаления:")
                for i, product in enumerate(products, 1):
                    print(f"{i}. {product['name']} ({product['code']})")
                
                try:
                    idx = int(input("Номер товара: ")) - 1
                    if 0 <= idx < len(products):
                        deleted = products.pop(idx)
                        ProductSystem.save_products(products)
                        print(f"\nТовар '{deleted['name']}' удален!")
                    else:
                        print("\nНеверный номер товара!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '4':
                if not products:
                    print("\nНет товаров для изменения!")
                    input("Нажмите Enter чтобы продолжить...")
                    continue
                
                print("\nВыберите товар для изменения цены:")
                for i, product in enumerate(products, 1):
                    print(f"{i}. {product['name']} - {product['price']:.2f} руб.")
                
                try:
                    idx = int(input("Номер товара: ")) - 1
                    if 0 <= idx < len(products):
                        new_price = float(input("Новая цена: "))
                        if new_price > 0:
                            products[idx]['price'] = new_price
                            ProductSystem.save_products(products)
                            print(f"\nЦена изменена на {new_price:.2f} руб.")
                        else:
                            print("\nЦена должна быть положительной!")
                    else:
                        print("\nНеверный номер товара!")
                    input("Нажмите Enter чтобы продолжить...")
                except ValueError:
                    print("\nОшибка ввода!")
                    input("Нажмите Enter чтобы продолжить...")
            
            elif choice == '5':
                break
            
            else:
                print("Неверный выбор!")
    
    @staticmethod
    def view_history():
        history = DataManager.load_data(CONFIG['history_file'])
        
        print("\n=== ИСТОРИЯ ПОКУПОК ===")
        if not history:
            print("История покупок пуста")
            input("\nНажмите Enter чтобы продолжить...")
            return
        
        # Фильтрация по дате
        date_filter = input("Введите дату для фильтра (дд.мм.гггг или Enter для всех): ")
        filtered = []
        
        for record in history:
            record_date = datetime.strptime(record['date'], '%Y-%m-%d %H:%M:%S').strftime('%d.%m.%Y')
            if not date_filter or date_filter == record_date:
                filtered.append(record)
        
        if not filtered:
            print("Нет записей за указанную дату")
            input("\nНажмите Enter чтобы продолжить...")
            return
        
        # Постраничный вывод
        page = 0
        page_size = 5
        total_pages = (len(filtered) + page_size - 1) // page_size
        
        while True:
            print(f"\nСтраница {page + 1} из {total_pages}")
            for i in range(page * page_size, min((page + 1) * page_size, len(filtered))):
                record = filtered[i]
                print(f"\n=== {record['date']} ===")
                print(f"Способ оплаты: {record['payment_method']}")
                
                if 'card_number' in record:
                    print(f"Карта: ****{record['card_number'][-4:]}")
                if 'cash_received' in record:
                    print(f"Внесено: {record['cash_received']:.2f} руб.")
                    print(f"Сдача: {record['change']:.2f} руб.")
                
                print("\nТОВАРЫ:")
                for item in record['items']:
                    print(f"{item['product']['name']} - {item['product']['price']} руб. x{item['quantity']}")
                
                print(f"\nИТОГО: {record['total']:.2f} руб.")
                print("-" * 40)
            
            print("\nn - следующая, p - предыдущая, q - выход")
            cmd = input("Команда: ").lower()
            
            if cmd == 'n' and page < total_pages - 1:
                page += 1
            elif cmd == 'p' and page > 0:
                page -= 1
            elif cmd == 'q':
                break
            else:
                print("Неверная команда!")
    
    @staticmethod
    def manage_settings():
        print("\n=== НАСТРОЙКИ СИСТЕМЫ ===")
        print(f"1. Порог для скидки: {CONFIG['discount_threshold']} руб.")
        print(f"2. Размер скидки: {CONFIG['discount_percent']}%")
        print(f"3. Порог для PIN-кода: {CONFIG['pin_required_threshold']} руб.")
        print("4. Сменить пароль администратора")
        print("5. Назад")
        
        choice = input("Выберите параметр для изменения: ")
        
        if choice == '1':
            try:
                value = float(input("Новый порог для скидки: "))
                if value >= 0:
                    CONFIG['discount_threshold'] = value
                    print("Порог скидки обновлен!")
                else:
                    print("Значение должно быть положительным!")
            except ValueError:
                print("Неверное значение!")
        
        elif choice == '2':
            try:
                value = float(input("Новый размер скидки (%): "))
                if 0 <= value <= 100:
                    CONFIG['discount_percent'] = value
                    print("Размер скидки обновлен!")
                else:
                    print("Значение должно быть от 0 до 100!")
            except ValueError:
                print("Неверное значение!")
        
        elif choice == '3':
            try:
                value = float(input("Новый порог для PIN-кода: "))
                if value >= 0:
                    CONFIG['pin_required_threshold'] = value
                    print("Порог для PIN-кода обновлен!")
                else:
                    print("Значение должно быть положительным!")
            except ValueError:
                print("Неверное значение!")
        
        elif choice == '4':
            current = getpass("Текущий пароль: ")
            if hashlib.sha256(current.encode()).hexdigest() != CONFIG['admin_password_hash']:
                print("Неверный пароль!")
            else:
                new_pass = getpass("Новый пароль: ")
                confirm = getpass("Подтвердите пароль: ")
                if new_pass == confirm:
                    CONFIG['admin_password_hash'] = hashlib.sha256(new_pass.encode()).hexdigest()
                    print("Пароль успешно изменен!")
                else:
                    print("Пароли не совпадают!")
        
        elif choice == '5':
            return
        
        else:
            print("Неверный выбор!")

# Главное меню программы
def main_menu():
    cart = ShoppingCart()
    init_files()
    
    while True:
        print("\n=== ГЛАВНОЕ МЕНЮ ===")
        print("1. Режим покупок")
        print("2. Администратор")
        print("3. Выход")
        
        choice = input("Выберите действие: ")
        
        if choice == '1':
            shopping_mode(cart)
        elif choice == '2':
            AdminPanel.show_menu()
        elif choice == '3':
            print("\nДо свидания!")
            break
        else:
            print("Неверный выбор!")

# Режим покупок
def shopping_mode(cart):
    while True:
        print("\n=== РЕЖИМ ПОКУПОК ===")
        print("1. Сканировать товар")
        print("2. Просмотреть корзину")
        print("3. Оплатить")
        print("4. Очистить корзину")
        print("5. Вернуться в меню")
        
        choice = input("Выберите действие: ")
        
        if choice == '1':
            Scanner.scan_product(cart)
        elif choice == '2':
            cart.edit_interactive()
        elif choice == '3':
            PaymentSystem.process_payment(cart)
        elif choice == '4':
            cart.clear()
            input("Нажмите Enter чтобы продолжить...")
        elif choice == '5':
            return
        else:
            print("Неверный выбор!")

if __name__ == "__main__":
    main_menu()